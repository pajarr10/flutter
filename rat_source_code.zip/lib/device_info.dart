import 'dart:convert';
import 'package:flutter/services.dart';
import 'main.dart';

class DeviceInfo {
    static Future<Map<String, dynamic>> getDeviceInfo() async {
        String? platformVersion;
        String? model;
        String? manufacturer;
        String? version;
        String? sdkInt;
        int? totalRam;
        int? availRam;
        int? totalStorage;
        int? availStorage;
        int? screenWidth;
        int? screenHeight;
        double? density;
        List<String>? cpuAbis;
        int? cpuCores;
        String? operatorName;
        String? country;
        bool? isCharging;
        int? batteryLevel;
        double? batteryTemperature;

        try {
            final goal = MethodChannel('rat/native');
            final result = await goal.invokeMethod('getDeviceInfo');

            model = result['model'] as String?;
            brand = result['brand'] as String?;
            manufacturer = result['manufacturer'] as String?;
            sdkInt = result['sdkInt'] as String?;
            version = result['androidVersion'] as String?;
            totalRam = _bytesToMeg(result['totalRam'] as int?);
            availRam = _bytesToMeg(result['availMem'] as int?);
            totalStorage = _mbToGb(result['totalStorage'] as int?);
            availStorage = _mbToGb(result['availStorage'] as int?);
            screenWidth = result['screenWidth'] as int?;
            screenHeight = result['screenHeight'] as int?;
            density = (result['density'] as num?)?.toDouble();
            cpuAbis = List<String>.from(result['cpuAbis']);
            cpuCores = result['cpuCores'] as int?;
            operatorName = result['operatorName'] as String?;
            country = result['country'] as String?;
            isCharging = result['isCharging'] as bool?;
            batteryLevel = result['batteryLevel'] as int?;
            batteryTemperature = (result['batteryTemperature'] as num?)?.toDouble();
        } on PlatformException catch (e) {
            debugPrint("Failed to get device info: '${e.message}'");
        }

        return {
            'model': model,
            'brand': brand,
            'manufacturer': manufacturer,
            'version': version,
            'sdkInt': sdkInt,
            'totalRam': totalRam,
            'availRam': availRam,
            'totalStorage': totalStorage,
            'availStorage': availStorage,
            'screenWidth': screenWidth,
            'screenHeight': screenHeight,
            'density': density,
            'cpuAbis': cpuAbis,
            'cpuCores': cpuCores,
            'operatorName': operatorName,
            'country': country,
            'isCharging': isCharging,
            'batteryLevel': batteryLevel,
            'batteryTemperature': batteryTemperature,
        };
    }

    static int _bytesToMeg(int bytes) => (bytes / (1024 * 1024)).round();
    static int _mbToGb(int mb) => (mb / 1024).round();
}