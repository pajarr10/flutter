import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ConnectionHandler {
    final String url;
    final String deviceId;
    late final WebSocketChannel channel;
    int _reconnectCounter = 0;
    bool _isConnected = false;
    final Map<String, dynamic> Function(dynamic)? _responseHandler;

    ConnectionHandler(this.url, this.deviceId);

    Future<void> init() async {
        channel = WebSocketChannel.connect(Uri.parse(url + '?device_id=$deviceId'));
        channel.stream.listen(_onMessage, onError: _onError, onDone: _onDone);
        await _waitForConnection();
    }

    Future<void> _waitForConnection() async {
        await Future.delayed(const Duration(seconds: 3));
        if (!channel.sink.isReady) {
            _reconnectCounter++;
            if (_reconnectCounter < 6) {
                await Future.delayed(_getBackoffTime());
                init();
            }
        }
    }

    Duration _getBackoffTime() {
        final times = [1000, 2000, 4000, 8000, 16000];
        return Duration(milliseconds: times[_reconnectCounter - 1].clamp(1000, 30000));
    }

    void _onMessage(dynamic message) {
        final decoded = jsonDecode(message) as Map<String, dynamic>;
        _isConnected = decoded['type'] == 'connected';
        // Handle incoming messages
    }

    void _onError(Object error) {
        debugPrint('WebSocket error: $error');
        _reconnectCounter++;
        if (_reconnectCounter < 6) {
            init();
        }
    }

    void _onDone() {
        _reconnectCounter++;
        if (_reconnectCounter < 6) {
            init();
        }
    }

    void startHeartbeat() {
        // Send ping every 30 seconds
        Timer.periodic(const Duration(seconds: 30), (timer) {
            if (channel.sink.isOpen) {
                channel.sink.add(jsonEncode({
                    'type': 'heartbeat',
                    'device_id': deviceId,
                    'payload': {
                        'model': _deviceInfo['model'],
                        'battery': _deviceInfo['batteryLevel'],
                        'ram': _deviceInfo['availMem'],
                        'storage': _deviceInfo['availStorage'],
                        'charging': _deviceInfo['isCharging']
                    }
                }));
            } else {
                timer.cancel();
                init();
            }
        });
    }

    void sendResponse(Map<String, dynamic> response, String? deviceId) {
        final msg = jsonEncode({
            'type': 'response',
            'device_id': deviceId ?? this.deviceId,
            'action': response['action'],
            'payload': response['payload'],
            'status': response['status'],
            'message': response['message'],
            'timestamp': DateTime.now().millisecondsSinceEpoch,
        });
        if (channel.sink.isOpen) {
            channel.sink.add(msg);
        }
    }

    void dispose() {
        channel.sink.close();
    }
}